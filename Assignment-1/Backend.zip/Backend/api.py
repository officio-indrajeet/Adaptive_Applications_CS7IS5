from flask import Flask, request, jsonify
from model import User, db
import pickle
import numpy as np

# Load the SVM model
model = pickle.load(open('svm_model.pkl', 'rb'))

def score_to_category(normalized_score):
    """Convert normalized score to category based on specified thresholds."""
    if normalized_score > 85:
        return "High"
    elif normalized_score >= 65:
        return "Medium"
    else:
        return "Low"

def configure_routes(app):

    @app.route('/submit', methods=['POST'])
    def submit_user_data():
        data = request.get_json()
        if not data:
            return jsonify({'message': 'No input data provided'}), 400
        
        try:
            # Create a new user instance from the provided data
            new_user = User(
                name=data.get('name'), age=data.get('age'), residence=data.get('residence'),
                native_language=data.get('native_language'), gre_verbal=data.get('gre_verbal'),
                gre_quant=data.get('gre_quant'), gre_analytical=data.get('gre_analytical'),
                cgpa=data.get('cgpa')
            )
            # Add the new user to the session and commit it to the database
            db.session.add(new_user)
            db.session.commit()

            # Prepare data for prediction
            input_features = [new_user.gre_verbal, new_user.gre_quant, new_user.gre_analytical, new_user.cgpa]
            # Get decision function scores for all classes
            scores = model.decision_function([input_features])[0]
            # Get the indices of the top 7 scores
            top_indices = np.argsort(scores)[-7:][::-1]
            # Get the university names for the top indices
            top_universities_scores = [(model.classes_[i], scores[i]) for i in top_indices]

            # Normalize scores to a 0-100 scale for categorization
            min_score, max_score = min(scores), max(scores)
            scores_normalized = [(score - min_score) / (max_score - min_score) * 100 for score in scores]
            # Convert scores to categories
            categories = [score_to_category(score) for score in scores_normalized]

            # Pair universities with their categories and normalized scores
            universities_with_categories = [
                (uni, f"{normalized_score:.2f}%", category)
                for (uni, score), normalized_score, category in zip(top_universities_scores, scores_normalized, categories)
            ]

            # Return the prediction result with the user data add success message
            return jsonify({
                'message': 'User data added and prediction made successfully!',
                'prediction': universities_with_categories
            }), 201
        except Exception as e:
            db.session.rollback()
            return jsonify({'message': 'Failed to add user data', 'error': str(e)}), 500
