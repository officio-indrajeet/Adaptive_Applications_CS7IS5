from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    age = db.Column(db.Integer, nullable=False)
    residence = db.Column(db.String(100), nullable=False)
    native_language = db.Column(db.String(50), nullable=False)
    gre_verbal = db.Column(db.Float, nullable=False)
    gre_quant = db.Column(db.Float, nullable=False)
    gre_analytical = db.Column(db.Float, nullable=False)
    cgpa = db.Column(db.Float, nullable=False)

def setup_database(app):
    with app.app_context():
        db.create_all()
